function toolbox;
% function to run all tools;
WL_tool  % launch window level tool (button)
PZ_tool  % launch Pan-Zoom tool (button)
ROI_tool % launch ROI tool (button)
MV_tool  % launch movie tool (button)
PM_tool  % launch pixel (point) measurement tool (button)
RT_tool  % launch rotate/flip tool (button)